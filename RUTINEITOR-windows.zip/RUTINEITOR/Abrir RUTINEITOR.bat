@echo off
rem Abre RUTINEITOR con el Java que viene en esta carpeta
start "" "%~dp0jre\bin\javaw.exe" -jar "%~dp0rutineitor.jar"
